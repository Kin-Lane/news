package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Blog;
import io.swagger.client.model.Tag;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class TagsApi {
  String basePath = "https://blog.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * blog tags by week
   * blog tags by week
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @param week the week to retrieve tags by
   * @param year the year to retrieve tags by
   * @return List<Blog>
   */
  public List<Blog> getBlogTagsByWeek (String appid, String appkey, String week, String year) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/tags/byweek/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    if (year != null)
      queryParams.put("year", ApiInvoker.parameterToString(year));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * blog tags by week blogs
   * blog tags by week blogs
   * @param tag the tag to filter by
   * @param week the week to filter by, defaults to this week
   * @return List<Blog>
   */
  public List<Blog> getBlogTagCBlog (String tag, String week) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/tags/byweek/{tag}/blog/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "tag" + "\\}", apiInvoker.escapeString(tag.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (week != null)
      queryParams.put("week", ApiInvoker.parameterToString(week));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * blog tags
   * blog tags
   * @param blogId id for blog
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @return List<Tag>
   */
  public List<Tag> getblogTags (String blogId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/{blog_id}/tags/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "blogId" + "\\}", apiInvoker.escapeString(blogId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add tag to blog
   * add tag to blog
   * @param blogId id for the blog
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @param tag tag name
   * @return List<Tag>
   */
  public List<Tag> addBlogTag (String blogId, String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/{blog_id}/tags/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "blogId" + "\\}", apiInvoker.escapeString(blogId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (tag != null)
      queryParams.put("tag", ApiInvoker.parameterToString(tag));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete blog tag
   * delete blog tag
   * @param blogId id for the blog
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @param tag tag to remove from blog
   * @return List<Tag>
   */
  public List<Tag> deleteblogTag (String blogId, String appid, String appkey, String tag) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/{blog_id}/tags/{tag}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "blogId" + "\\}", apiInvoker.escapeString(blogId.toString()))
      .replaceAll("\\{" + "tag" + "\\}", apiInvoker.escapeString(tag.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Tag>) ApiInvoker.deserialize(response, "array", Tag.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
