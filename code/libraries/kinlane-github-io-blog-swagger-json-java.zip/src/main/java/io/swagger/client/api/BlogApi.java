package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Blog;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class BlogApi {
  String basePath = "https://blog.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * all blogs
   * all blogs
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @param query a text query to search across blog
   * @return List<Blog>
   */
  public List<Blog> getBlogs (String appid, String appkey, String query) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add a blog post
   * add a blog post
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @param postDate date the blog was posted
   * @param title ttle for the blog
   * @param author author of the blog
   * @param summary summary for the blog
   * @param body full text for the blog
   * @param footer curated id the blog originated from
   * @param status status of the blog
   * @param curatedId full text for the blog
   * @return List<Blog>
   */
  public List<Blog> addBlog (String appid, String appkey, String postDate, String title, String author, String summary, String body, String footer, String status, String curatedId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (postDate != null)
      queryParams.put("post_date", ApiInvoker.parameterToString(postDate));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (summary != null)
      queryParams.put("summary", ApiInvoker.parameterToString(summary));
    if (body != null)
      queryParams.put("body", ApiInvoker.parameterToString(body));
    if (footer != null)
      queryParams.put("footer", ApiInvoker.parameterToString(footer));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (curatedId != null)
      queryParams.put("curated_id", ApiInvoker.parameterToString(curatedId));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * blogs by week
   * blogs by week
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @return List<Blog>
   */
  public List<Blog> getBlogsByWeek (String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/byweek/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * draft blogs
   * draft blogs
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @return List<Blog>
   */
  public List<Blog> getDraftBlogs (String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/draft/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * published blogs
   * published blogs
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @return List<Blog>
   */
  public List<Blog> getPublishedBlogs (String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/published/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * Retrieve a blog using its slug
   * Returns the blog detail
   * @param blogId the unique id for blog entry
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @return List<Blog>
   */
  public List<Blog> getBlog (String blogId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/{blog_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "blogId" + "\\}", apiInvoker.escapeString(blogId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * update blog
   * update blog
   * @param blogId the unique id for blog entry
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @param postDate date the blog was posted
   * @param title ttle for the blog
   * @param author author of the blog
   * @param summary summary for the blog
   * @param body full text for the blog
   * @param footer curated id the blog originated from
   * @param status status of the blog
   * @param curatedId full text for the blog
   * @return List<Blog>
   */
  public List<Blog> updateBlog (String blogId, String appid, String appkey, String postDate, String title, String author, String summary, String body, String footer, String status, String curatedId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/{blog_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "blogId" + "\\}", apiInvoker.escapeString(blogId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (postDate != null)
      queryParams.put("post_date", ApiInvoker.parameterToString(postDate));
    if (title != null)
      queryParams.put("title", ApiInvoker.parameterToString(title));
    if (author != null)
      queryParams.put("author", ApiInvoker.parameterToString(author));
    if (summary != null)
      queryParams.put("summary", ApiInvoker.parameterToString(summary));
    if (body != null)
      queryParams.put("body", ApiInvoker.parameterToString(body));
    if (footer != null)
      queryParams.put("footer", ApiInvoker.parameterToString(footer));
    if (status != null)
      queryParams.put("status", ApiInvoker.parameterToString(status));
    if (curatedId != null)
      queryParams.put("curated_id", ApiInvoker.parameterToString(curatedId));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete blog
   * delete blog
   * @param blogId the unique id for blog entry
   * @param appid your appid for accessing the blog
   * @param appkey your appkey for accessing the blog
   * @return List<Blog>
   */
  public List<Blog> deleteBlog (String blogId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/blog/{blog_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "blogId" + "\\}", apiInvoker.escapeString(blogId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Blog>) ApiInvoker.deserialize(response, "array", Blog.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}
