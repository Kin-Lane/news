using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class BlogApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public BlogApi(String basePath = "https://blog.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// all blogs all blogs
    /// </summary>
    /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
     /// <param name="Query">a text query to search across blog</param>
    
    /// <returns></returns>
    public List<blog>  GetBlogs (string Appid, string Appkey, string Query) {
      // create path and map variables
      var path = "/blog/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add a blog post add a blog post
    /// </summary>
    /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
     /// <param name="PostDate">date the blog was posted</param>
     /// <param name="Title">ttle for the blog</param>
     /// <param name="Author">author of the blog</param>
     /// <param name="Summary">summary for the blog</param>
     /// <param name="Body">full text for the blog</param>
     /// <param name="Footer">curated id the blog originated from</param>
     /// <param name="Status">status of the blog</param>
     /// <param name="CuratedId">full text for the blog</param>
    
    /// <returns></returns>
    public List<blog>  AddBlog (string Appid, string Appkey, string PostDate, string Title, string Author, string Summary, string Body, string Footer, string Status, string CuratedId) {
      // create path and map variables
      var path = "/blog/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (PostDate != null){
        queryParams.Add("post_date", apiInvoker.ParameterToString(PostDate));
      }
      if (Title != null){
        queryParams.Add("title", apiInvoker.ParameterToString(Title));
      }
      if (Author != null){
        queryParams.Add("author", apiInvoker.ParameterToString(Author));
      }
      if (Summary != null){
        queryParams.Add("summary", apiInvoker.ParameterToString(Summary));
      }
      if (Body != null){
        queryParams.Add("body", apiInvoker.ParameterToString(Body));
      }
      if (Footer != null){
        queryParams.Add("footer", apiInvoker.ParameterToString(Footer));
      }
      if (Status != null){
        queryParams.Add("status", apiInvoker.ParameterToString(Status));
      }
      if (CuratedId != null){
        queryParams.Add("curated_id", apiInvoker.ParameterToString(CuratedId));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// blogs by week blogs by week
    /// </summary>
    /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
    
    /// <returns></returns>
    public List<blog>  GetBlogsByWeek (string Appid, string Appkey) {
      // create path and map variables
      var path = "/blog/byweek/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// draft blogs draft blogs
    /// </summary>
    /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
    
    /// <returns></returns>
    public List<blog>  GetDraftBlogs (string Appid, string Appkey) {
      // create path and map variables
      var path = "/blog/draft/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// published blogs published blogs
    /// </summary>
    /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
    
    /// <returns></returns>
    public List<blog>  GetPublishedBlogs (string Appid, string Appkey) {
      // create path and map variables
      var path = "/blog/published/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// Retrieve a blog using its slug Returns the blog detail
    /// </summary>
    /// <param name="BlogId">the unique id for blog entry</param>
     /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
    
    /// <returns></returns>
    public List<blog>  GetBlog (string BlogId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/blog/{blog_id}/".Replace("{format}","json").Replace("{" + "blog_id" + "}", apiInvoker.ParameterToString(BlogId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// update blog update blog
    /// </summary>
    /// <param name="BlogId">the unique id for blog entry</param>
     /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
     /// <param name="PostDate">date the blog was posted</param>
     /// <param name="Title">ttle for the blog</param>
     /// <param name="Author">author of the blog</param>
     /// <param name="Summary">summary for the blog</param>
     /// <param name="Body">full text for the blog</param>
     /// <param name="Footer">curated id the blog originated from</param>
     /// <param name="Status">status of the blog</param>
     /// <param name="CuratedId">full text for the blog</param>
    
    /// <returns></returns>
    public List<blog>  UpdateBlog (string BlogId, string Appid, string Appkey, string PostDate, string Title, string Author, string Summary, string Body, string Footer, string Status, string CuratedId) {
      // create path and map variables
      var path = "/blog/{blog_id}/".Replace("{format}","json").Replace("{" + "blog_id" + "}", apiInvoker.ParameterToString(BlogId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (PostDate != null){
        queryParams.Add("post_date", apiInvoker.ParameterToString(PostDate));
      }
      if (Title != null){
        queryParams.Add("title", apiInvoker.ParameterToString(Title));
      }
      if (Author != null){
        queryParams.Add("author", apiInvoker.ParameterToString(Author));
      }
      if (Summary != null){
        queryParams.Add("summary", apiInvoker.ParameterToString(Summary));
      }
      if (Body != null){
        queryParams.Add("body", apiInvoker.ParameterToString(Body));
      }
      if (Footer != null){
        queryParams.Add("footer", apiInvoker.ParameterToString(Footer));
      }
      if (Status != null){
        queryParams.Add("status", apiInvoker.ParameterToString(Status));
      }
      if (CuratedId != null){
        queryParams.Add("curated_id", apiInvoker.ParameterToString(CuratedId));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete blog delete blog
    /// </summary>
    /// <param name="BlogId">the unique id for blog entry</param>
     /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
    
    /// <returns></returns>
    public List<blog>  DeleteBlog (string BlogId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/blog/{blog_id}/".Replace("{format}","json").Replace("{" + "blog_id" + "}", apiInvoker.ParameterToString(BlogId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
