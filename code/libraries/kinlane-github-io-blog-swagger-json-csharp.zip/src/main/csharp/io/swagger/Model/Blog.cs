using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Blog {
    

    /* date the blog was posted */
    
    public string PostDate { get; set; }

    

    /* ttle for the blog */
    
    public string Title { get; set; }

    

    /* author of the blog */
    
    public string Author { get; set; }

    

    /* summary for the blog */
    
    public string Summary { get; set; }

    

    /* full body text of the blog */
    
    public string Body { get; set; }

    

    /* footer text for the blog */
    
    public string Footer { get; set; }

    

    /* status of the blog */
    
    public string Status { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Blog {\n");
      
      sb.Append("  PostDate: ").Append(PostDate).Append("\n");
      
      sb.Append("  Title: ").Append(Title).Append("\n");
      
      sb.Append("  Author: ").Append(Author).Append("\n");
      
      sb.Append("  Summary: ").Append(Summary).Append("\n");
      
      sb.Append("  Body: ").Append(Body).Append("\n");
      
      sb.Append("  Footer: ").Append(Footer).Append("\n");
      
      sb.Append("  Status: ").Append(Status).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}