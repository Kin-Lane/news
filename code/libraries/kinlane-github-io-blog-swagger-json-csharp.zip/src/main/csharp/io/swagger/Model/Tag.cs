using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Tag {
    

    /* text tag */
    
    public string Tag { get; set; }

    

    /* number of items api with tag */
    
    public int? ApiCount { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Tag {\n");
      
      sb.Append("  Tag: ").Append(Tag).Append("\n");
      
      sb.Append("  ApiCount: ").Append(ApiCount).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}