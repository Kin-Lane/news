using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class TagsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public TagsApi(String basePath = "https://blog.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// blog tags by week blog tags by week
    /// </summary>
    /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
     /// <param name="Week">the week to retrieve tags by</param>
     /// <param name="Year">the year to retrieve tags by</param>
    
    /// <returns></returns>
    public List<blog>  GetBlogTagsByWeek (string Appid, string Appkey, string Week, string Year) {
      // create path and map variables
      var path = "/blog/tags/byweek/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Week != null){
        queryParams.Add("week", apiInvoker.ParameterToString(Week));
      }
      if (Year != null){
        queryParams.Add("year", apiInvoker.ParameterToString(Year));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// blog tags by week blogs blog tags by week blogs
    /// </summary>
    /// <param name="Tag">the tag to filter by</param>
     /// <param name="Week">the week to filter by, defaults to this week</param>
    
    /// <returns></returns>
    public List<blog>  GetBlogTagCBlog (string Tag, string Week) {
      // create path and map variables
      var path = "/blog/tags/byweek/{tag}/blog/".Replace("{format}","json").Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Week != null){
        queryParams.Add("week", apiInvoker.ParameterToString(Week));
      }
      

      

      

      try {
        if (typeof(List<blog>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<blog>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<blog>) ApiInvoker.deserialize(response, typeof(List<blog>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// blog tags blog tags
    /// </summary>
    /// <param name="BlogId">id for blog</param>
     /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
    
    /// <returns></returns>
    public List<tag>  GetblogTags (string BlogId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/blog/{blog_id}/tags/".Replace("{format}","json").Replace("{" + "blog_id" + "}", apiInvoker.ParameterToString(BlogId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add tag to blog add tag to blog
    /// </summary>
    /// <param name="BlogId">id for the blog</param>
     /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
     /// <param name="Tag">tag name</param>
    
    /// <returns></returns>
    public List<tag>  AddBlogTag (string BlogId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/blog/{blog_id}/tags/".Replace("{format}","json").Replace("{" + "blog_id" + "}", apiInvoker.ParameterToString(BlogId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Tag != null){
        queryParams.Add("tag", apiInvoker.ParameterToString(Tag));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete blog tag delete blog tag
    /// </summary>
    /// <param name="BlogId">id for the blog</param>
     /// <param name="Appid">your appid for accessing the blog</param>
     /// <param name="Appkey">your appkey for accessing the blog</param>
     /// <param name="Tag">tag to remove from blog</param>
    
    /// <returns></returns>
    public List<tag>  DeleteblogTag (string BlogId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/blog/{blog_id}/tags/{tag}".Replace("{format}","json").Replace("{" + "blog_id" + "}", apiInvoker.ParameterToString(BlogId)).Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
