package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Blog  {
  
  private String postDate = null;
  private String title = null;
  private String author = null;
  private String summary = null;
  private String body = null;
  private String footer = null;
  private String status = null;

  
  /**
   * date the blog was posted
   **/
  @ApiModelProperty(value = "date the blog was posted")
  @JsonProperty("post_date")
  public String getPostDate() {
    return postDate;
  }
  public void setPostDate(String postDate) {
    this.postDate = postDate;
  }

  
  /**
   * ttle for the blog
   **/
  @ApiModelProperty(value = "ttle for the blog")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  
  /**
   * author of the blog
   **/
  @ApiModelProperty(value = "author of the blog")
  @JsonProperty("author")
  public String getAuthor() {
    return author;
  }
  public void setAuthor(String author) {
    this.author = author;
  }

  
  /**
   * summary for the blog
   **/
  @ApiModelProperty(value = "summary for the blog")
  @JsonProperty("summary")
  public String getSummary() {
    return summary;
  }
  public void setSummary(String summary) {
    this.summary = summary;
  }

  
  /**
   * full body text of the blog
   **/
  @ApiModelProperty(value = "full body text of the blog")
  @JsonProperty("body")
  public String getBody() {
    return body;
  }
  public void setBody(String body) {
    this.body = body;
  }

  
  /**
   * footer text for the blog
   **/
  @ApiModelProperty(value = "footer text for the blog")
  @JsonProperty("footer")
  public String getFooter() {
    return footer;
  }
  public void setFooter(String footer) {
    this.footer = footer;
  }

  
  /**
   * status of the blog
   **/
  @ApiModelProperty(value = "status of the blog")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Blog {\n");
    
    sb.append("  postDate: ").append(postDate).append("\n");
    sb.append("  title: ").append(title).append("\n");
    sb.append("  author: ").append(author).append("\n");
    sb.append("  summary: ").append(summary).append("\n");
    sb.append("  body: ").append(body).append("\n");
    sb.append("  footer: ").append(footer).append("\n");
    sb.append("  status: ").append(status).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}
