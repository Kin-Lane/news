#import <Foundation/Foundation.h>
#import "SWGBlog.h"
#import "SWGTag.h"
#import "SWGObject.h"


@interface SWGTagsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTagsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 blog tags by week
 blog tags by week

 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 @param week the week to retrieve tags by
 @param year the year to retrieve tags by
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getBlogTagsByWeekWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     week:(NSString*) week 
     year:(NSString*) year 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 blog tags by week blogs
 blog tags by week blogs

 @param tag the tag to filter by
 @param week the week to filter by, defaults to this week
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getBlogTagCBlogWithCompletionBlock :(NSString*) tag 
     week:(NSString*) week 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 blog tags
 blog tags

 @param blog_id id for blog
 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) getblogTagsWithCompletionBlock :(NSString*) blog_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 add tag to blog
 add tag to blog

 @param blog_id id for the blog
 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 @param tag tag name
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) addBlogTagWithCompletionBlock :(NSString*) blog_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 delete blog tag
 delete blog tag

 @param blog_id id for the blog
 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 @param tag tag to remove from blog
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) deleteblogTagWithCompletionBlock :(NSString*) blog_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    



@end