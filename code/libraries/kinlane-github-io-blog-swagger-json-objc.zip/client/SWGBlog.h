#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGBlog
@end
  
@interface SWGBlog : SWGObject

/* date the blog was posted [optional]
 */
@property(nonatomic) NSString* post_date;
/* ttle for the blog [optional]
 */
@property(nonatomic) NSString* title;
/* author of the blog [optional]
 */
@property(nonatomic) NSString* author;
/* summary for the blog [optional]
 */
@property(nonatomic) NSString* summary;
/* full body text of the blog [optional]
 */
@property(nonatomic) NSString* body;
/* footer text for the blog [optional]
 */
@property(nonatomic) NSString* footer;
/* status of the blog [optional]
 */
@property(nonatomic) NSString* status;

@end
