#import <Foundation/Foundation.h>
#import "SWGBlog.h"
#import "SWGObject.h"


@interface SWGBlogApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGBlogApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 all blogs
 all blogs

 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 @param query a text query to search across blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getBlogsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 add a blog post
 add a blog post

 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 @param post_date date the blog was posted
 @param title ttle for the blog
 @param author author of the blog
 @param summary summary for the blog
 @param body full text for the blog
 @param footer curated id the blog originated from
 @param status status of the blog
 @param curated_id full text for the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) addBlogWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     post_date:(NSString*) post_date 
     title:(NSString*) title 
     author:(NSString*) author 
     summary:(NSString*) summary 
     body:(NSString*) body 
     footer:(NSString*) footer 
     status:(NSString*) status 
     curated_id:(NSString*) curated_id 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 blogs by week
 blogs by week

 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getBlogsByWeekWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 draft blogs
 draft blogs

 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getDraftBlogsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 published blogs
 published blogs

 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getPublishedBlogsWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 Retrieve a blog using its slug
 Returns the blog detail

 @param blog_id the unique id for blog entry
 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) getBlogWithCompletionBlock :(NSString*) blog_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 update blog
 update blog

 @param blog_id the unique id for blog entry
 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 @param post_date date the blog was posted
 @param title ttle for the blog
 @param author author of the blog
 @param summary summary for the blog
 @param body full text for the blog
 @param footer curated id the blog originated from
 @param status status of the blog
 @param curated_id full text for the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) updateBlogWithCompletionBlock :(NSString*) blog_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     post_date:(NSString*) post_date 
     title:(NSString*) title 
     author:(NSString*) author 
     summary:(NSString*) summary 
     body:(NSString*) body 
     footer:(NSString*) footer 
     status:(NSString*) status 
     curated_id:(NSString*) curated_id 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    


/**

 delete blog
 delete blog

 @param blog_id the unique id for blog entry
 @param appid your appid for accessing the blog
 @param appkey your appkey for accessing the blog
 

 return type: NSArray<SWGBlog>*
 */
-(NSNumber*) deleteBlogWithCompletionBlock :(NSString*) blog_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBlog>* output, NSError* error))completionBlock;
    



@end