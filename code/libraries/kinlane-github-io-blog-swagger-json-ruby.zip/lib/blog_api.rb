require "uri"

class BlogApi
  basePath = "https://blog.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # all blogs
  # all blogs
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @option opts [string] :query a text query to search across blog
  # @return array[blog]
  def self.get_blogs(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = opts[:'query'] if opts[:'query']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # add a blog post
  # add a blog post
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param post_date date the blog was posted
  # @param title ttle for the blog
  # @param author author of the blog
  # @param summary summary for the blog
  # @param body full text for the blog
  # @param footer curated id the blog originated from
  # @param status status of the blog
  # @param curated_id full text for the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.add_blog(appid, appkey, post_date, title, author, summary, body, footer, status, curated_id, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "post_date is required" if post_date.nil?
    raise "title is required" if title.nil?
    raise "author is required" if author.nil?
    raise "summary is required" if summary.nil?
    raise "body is required" if body.nil?
    raise "footer is required" if footer.nil?
    raise "status is required" if status.nil?
    raise "curated_id is required" if curated_id.nil?

    # resource path
    path = "/blog/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'post_date'] = post_date
    query_params[:'title'] = title
    query_params[:'author'] = author
    query_params[:'summary'] = summary
    query_params[:'body'] = body
    query_params[:'footer'] = footer
    query_params[:'status'] = status
    query_params[:'curated_id'] = curated_id

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # blogs by week
  # blogs by week
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.get_blogs_by_week(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/byweek/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # draft blogs
  # draft blogs
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.get_draft_blogs(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/draft/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # published blogs
  # published blogs
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.get_published_blogs(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/published/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # Retrieve a blog using its slug
  # Returns the blog detail
  # @param blog_id the unique id for blog entry
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.get_blog(blog_id, appid, appkey, opts = {})
    # verify existence of params
    raise "blog_id is required" if blog_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/{blog_id}/".sub('{format}','json').sub('{' + 'blog_id' + '}', blog_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # update blog
  # update blog
  # @param blog_id the unique id for blog entry
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param post_date date the blog was posted
  # @param title ttle for the blog
  # @param author author of the blog
  # @param summary summary for the blog
  # @param body full text for the blog
  # @param footer curated id the blog originated from
  # @param status status of the blog
  # @param curated_id full text for the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.update_blog(blog_id, appid, appkey, post_date, title, author, summary, body, footer, status, curated_id, opts = {})
    # verify existence of params
    raise "blog_id is required" if blog_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "post_date is required" if post_date.nil?
    raise "title is required" if title.nil?
    raise "author is required" if author.nil?
    raise "summary is required" if summary.nil?
    raise "body is required" if body.nil?
    raise "footer is required" if footer.nil?
    raise "status is required" if status.nil?
    raise "curated_id is required" if curated_id.nil?

    # resource path
    path = "/blog/{blog_id}/".sub('{format}','json').sub('{' + 'blog_id' + '}', blog_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'post_date'] = post_date
    query_params[:'title'] = title
    query_params[:'author'] = author
    query_params[:'summary'] = summary
    query_params[:'body'] = body
    query_params[:'footer'] = footer
    query_params[:'status'] = status
    query_params[:'curated_id'] = curated_id

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:PUT, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # delete blog
  # delete blog
  # @param blog_id the unique id for blog entry
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.delete_blog(blog_id, appid, appkey, opts = {})
    # verify existence of params
    raise "blog_id is required" if blog_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/{blog_id}/".sub('{format}','json').sub('{' + 'blog_id' + '}', blog_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end
end
