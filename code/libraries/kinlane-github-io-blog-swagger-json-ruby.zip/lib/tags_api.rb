require "uri"

class TagsApi
  basePath = "https://blog.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # blog tags by week
  # blog tags by week
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param week the week to retrieve tags by
  # @param [Hash] opts the optional parameters
  # @option opts [string] :year the year to retrieve tags by
  # @return array[blog]
  def self.get_blog_tags_by_week(appid, appkey, week, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "week is required" if week.nil?

    # resource path
    path = "/blog/tags/byweek/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'week'] = week
    query_params[:'year'] = opts[:'year'] if opts[:'year']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # blog tags by week blogs
  # blog tags by week blogs
  # @param tag the tag to filter by
  # @param week the week to filter by, defaults to this week
  # @param [Hash] opts the optional parameters
  # @return array[blog]
  def self.get_blog_tag_c_blog(tag, week, opts = {})
    # verify existence of params
    raise "tag is required" if tag.nil?
    raise "week is required" if week.nil?

    # resource path
    path = "/blog/tags/byweek/{tag}/blog/".sub('{format}','json').sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'week'] = week

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| blog.new(response) }
  end

  # blog tags
  # blog tags
  # @param blog_id id for blog
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.getblog_tags(blog_id, appid, appkey, opts = {})
    # verify existence of params
    raise "blog_id is required" if blog_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/blog/{blog_id}/tags/".sub('{format}','json').sub('{' + 'blog_id' + '}', blog_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # add tag to blog
  # add tag to blog
  # @param blog_id id for the blog
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param tag tag name
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.add_blog_tag(blog_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "blog_id is required" if blog_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/blog/{blog_id}/tags/".sub('{format}','json').sub('{' + 'blog_id' + '}', blog_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'tag'] = tag

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end

  # delete blog tag
  # delete blog tag
  # @param blog_id id for the blog
  # @param appid your appid for accessing the blog
  # @param appkey your appkey for accessing the blog
  # @param tag tag to remove from blog
  # @param [Hash] opts the optional parameters
  # @return array[tag]
  def self.deleteblog_tag(blog_id, appid, appkey, tag, opts = {})
    # verify existence of params
    raise "blog_id is required" if blog_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tag is required" if tag.nil?

    # resource path
    path = "/blog/{blog_id}/tags/{tag}".sub('{format}','json').sub('{' + 'blog_id' + '}', blog_id.to_s).sub('{' + 'tag' + '}', tag.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tag.new(response) }
  end
end
