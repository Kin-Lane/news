
class Blog
  attr_accessor :post_date, :title, :author, :summary, :body, :footer, :status
  # :internal => :external
  def self.attribute_map
    {
      :post_date => :'post_date',
      :title => :'title',
      :author => :'author',
      :summary => :'summary',
      :body => :'body',
      :footer => :'footer',
      :status => :'status'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"post_date"]
      @post_date = attributes["post_date"]
    end
    
    if self.class.attribute_map[:"title"]
      @title = attributes["title"]
    end
    
    if self.class.attribute_map[:"author"]
      @author = attributes["author"]
    end
    
    if self.class.attribute_map[:"summary"]
      @summary = attributes["summary"]
    end
    
    if self.class.attribute_map[:"body"]
      @body = attributes["body"]
    end
    
    if self.class.attribute_map[:"footer"]
      @footer = attributes["footer"]
    end
    
    if self.class.attribute_map[:"status"]
      @status = attributes["status"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end
